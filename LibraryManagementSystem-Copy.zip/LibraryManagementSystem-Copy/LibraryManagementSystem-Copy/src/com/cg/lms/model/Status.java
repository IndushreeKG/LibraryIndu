package com.cg.lms.model;

public enum Status {
	ISSUED,RESERVED,AVAILABLE;
}
