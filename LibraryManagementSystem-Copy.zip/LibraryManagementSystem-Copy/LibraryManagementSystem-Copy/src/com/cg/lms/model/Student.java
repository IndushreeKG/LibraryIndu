package com.cg.lms.model;

public class Student {
	private String studId;
	private String name;
	
	public Student(){
		//left blank
	}

	public String getStudId() {
		return studId;
	}

	public void setStudId(String studId) {
		this.studId = studId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
