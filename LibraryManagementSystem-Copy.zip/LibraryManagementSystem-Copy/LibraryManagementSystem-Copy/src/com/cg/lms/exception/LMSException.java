package com.cg.lms.exception;

public class LMSException extends Exception{

		public LMSException(String errMsg){
			super(errMsg);
		}
}
